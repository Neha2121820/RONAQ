package com.bank.dao;

import com.bank.classes.Feedback;

public interface IFeedbackService {
public void addFeedback();
}
