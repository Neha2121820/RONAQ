package com.bank.dao;

import com.bank.classes.Feedback;

public interface IFeedbackDao {

public void addFeedback(Feedback feedback);
}
