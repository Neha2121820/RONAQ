package com.bank.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.bank.classes.Feedback;
import com.bank.dao.IFeedbackDao;

public class FeedbackDaoImpl implements IFeedbackDao {
SessionFactory sessionFactory;
Transaction tx;

		@Autowired
		public void setSessionFactory(SessionFactory sessionFactory)
		{this.sessionFactory=sessionFactory;
		}

		@Override
		public void addFeedback(Feedback feedback) {
			Session session=((SessionFactory) this.sessionFactory.getSessionFactoryOptions()).openSession();
		tx=session.beginTransaction();
		int i =(Integer)session.save(feedback);
		tx.commit();
		session.close();
		System.out.println("Feedback submitted");
			
		}	
		
		
}
