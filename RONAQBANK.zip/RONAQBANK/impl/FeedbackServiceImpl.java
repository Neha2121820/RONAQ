package com.bank.impl;

import org.springframework.transaction.annotation.Transactional;

import com.bank.classes.Feedback;
import com.bank.dao.IFeedbackDao;
import com.bank.dao.IFeedbackService;

public class FeedbackServiceImpl implements IFeedbackService{

	IFeedbackDao FeedbackDao;


	public void setFeedbackDao(IFeedbackDao feedbackDao) {
	this.FeedbackDao=FeedbackDao;
	}
	@Transactional
	
	public void addFeedback(Feedback Feedback) {
		FeedbackDao.addFeedback(Feedback);
		
	}
	@Override
	public void addFeedback() {
		
		
	}

}
