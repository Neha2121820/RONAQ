package com.bank.dao;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bank.model.Feedback;
@Repository
public class FeedbackDaoImpl implements IFeedbackDao {
SessionFactory sessionFactory;
Transaction tx;

		@Autowired
		public void setSessionFactory(SessionFactory sessionFactory)
		{
			this.sessionFactory=sessionFactory;
		}

		@Override
		public void addFeedback(Feedback feedback) {
			Session session= sessionFactory.openSession();
		tx=session.beginTransaction();
		int i =(Integer)session.save(feedback);
		tx.commit();
		session.close();
		System.out.println("Feedback submitted"+i);
			
		}	
		
		
}
