package com.bank.dao;

import org.springframework.stereotype.Repository;

import com.bank.model.Feedback;
@Repository
public interface IFeedbackDao {

public void addFeedback(Feedback feedback);
}
