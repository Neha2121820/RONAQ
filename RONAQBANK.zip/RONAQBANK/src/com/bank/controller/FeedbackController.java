package com.bank.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.bank.model.Feedback;
import com.bank.service.IFeedbackService;

@Controller
public class FeedbackController {
private IFeedbackService iFeedbackService;
@Autowired
public void setiFeedbackService(IFeedbackService iFeedbackService) {
	this.iFeedbackService = iFeedbackService;
}

@RequestMapping(value="/feedback")
public String addFeedback(Model model) {
model.addAttribute("Feedback",new Feedback());	
return "feedback";

}
}
