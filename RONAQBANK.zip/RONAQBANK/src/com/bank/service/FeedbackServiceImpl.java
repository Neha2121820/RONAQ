package com.bank.service;



import com.bank.model.Feedback;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bank.dao.IFeedbackDao;
@Service
public class FeedbackServiceImpl implements IFeedbackService{

	IFeedbackDao FeedbackDao;


	public void setFeedbackDao(IFeedbackDao feedbackDao) {
	this.FeedbackDao=FeedbackDao;
	}
	
	
	public void addFeedback(Feedback Feedback) {
		FeedbackDao.addFeedback(Feedback);
		
	}
	@Override
	public void addFeedback() {
		// TODO Auto-generated method stub
		
	}
		
	}


