package com.bank.service;

import org.springframework.stereotype.Service;


@Service
public interface IFeedbackService {
public void addFeedback();
}
