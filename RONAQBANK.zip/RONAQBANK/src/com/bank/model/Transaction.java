package com.bank.model;

import java.util.Date;

public class Transaction {
int transId;
String toAccount;
double amount;
Date date;
public int getTransId() {
	return transId;
}
public void setTransId(int transId) {
	this.transId = transId;
}
public String getToAccount() {
	return toAccount;
}
public void setToAccount(String toAccount) {
	this.toAccount = toAccount;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
@Override
public String toString() {
	return "Transaction [transId=" + transId + ", toAccount=" + toAccount + ", amount=" + amount + ", date=" + date
			+ "]";
}
public Transaction(int transId, String toAccount, double amount, Date date) {
	super();
	this.transId = transId;
	this.toAccount = toAccount;
	this.amount = amount;
	this.date = date;
}
public Transaction() {
	super();
}


}
